clear all;
close all;
clc;
%%

% Nom='../IMAGENES/Objeto12.BMP';
% Nom='tubo-1.tiff';
% Nom = 'Image__2016-05-12__15-15-16.tiff';
Nom = 'Image__2016-05-13__16-01-32.tiff';
% Nom = 'Image__2016-05-13__15-58-22.tiff';
% Nom = double(rgb2gray(imread('Image__2016-05-12__15-15-16.tiff')));

% En la seleccion del filtro deben hacer click en el centro y luego
% arrastrar la ventana.
[phased,FILTRE,M0,XF2,CE2]=analisis_TF(Nom);
[t,rec] = imcrop(imread(Nom));

% Aunque se extrae toda la fase de la imagen, para el unwrap es mejor
% quedarse con la parte donde esta la abolladura. Para eso se recorta.
phased = imcrop(phased,rec);
% phased=phased(50:end-50,50:end-50);
figure(101),imagesc(phased)
P1=round(ginput(1));
close(101)

%% Phase unwrap

choice = questdlg('Phase unwrap with mask?', ...
	'Dessert Menu', ...
	'Yes','No','No');

switch choice
    case 'No'
        phasec=unwrap2DClasico_Sin_Masc(P1(1),P1(2),phased);
        figure(301);imagesc(phasec);colormap(gray(256)); axis image
    case 'Yes'
        t = imcrop(imread(Nom),rec);
        figure(202),imshow(t)
        Mask = roipoly;
        figure(203), imshow(Mask)
        phasec=unwrap2DClasico([P1(1) P1(2)],phased,~Mask);
end
        
%% Interpolar puntos faltantes
if strcmp(choice,'Yes')
    
    [Y,X] = meshgrid(1:size(phasec,2),1:size(phasec,1));
    phasec_fix = griddata(X(~Mask),Y(~Mask),phasec(~Mask),X,Y);

    % [t,rec] = imcrop(imread(Nom));
    % phasec = imcrop(phasec,rec);
    % figure,imagesc(phased);

    figure(301);imagesc(phasec);colormap(gray(256)); axis image
    title('With problem')

    phasec = phasec_fix;
    figure(302);imagesc(phasec);colormap(gray(256)); axis image
    title('Fixed')
end
%% Estimar fase teorica y restar de fase continua
TT=Polyfit2D_1(phasec,ones(size(phasec)),1:size(phasec,2),1:size(phasec,1),3);
phasecT=PolyVal2D_1(TT,1:size(phasec,2),1:size(phasec,1),3);

% If one selects the right or left spectra
if CE2(1)>size(phased,2)/2
    phaseMap = -1*(phasec-phasecT);
else
    phaseMap = 1*(phasec-phasecT);
end
phaseMap = phaseMap-min(phaseMap(:));
% figure;imagesc(phasec-phasecT);colormap(gray(256));axis image
figure(303);imagesc(phaseMap);colormap(gray(256));axis image
colorbar

%% 
figure(304);mesh(flipud(phaseMap));colormap(gray(256));
% figure;contour3(-1*flipud(phasec-phasecT));colormap(gray(256));
% figure;mesh(flipud(phasecT));colormap(gray(256));
set(gca,'PlotBoxAspectRatio',[1 size(phaseMap,1)/size(phaseMap,2) 0.1])

%%
% [X,Y] = meshgrid(1:size(A,2),1:size(A,1));
% figure,mesh(X,Y,A), colormap gray
% figure;mesh(flipud(phasec));colormap(gray(256));